## Getting Started

### Prerequisites

Make sure you have the following tools installed on your system:

- CMake
- Make
- OpenGL

### Compiling and Running

To compile and run the project, execute the following commands in your terminal:
- open terminal in Project folder.
- Run following bash:-
    - cmake CMakeLists.txt
    - make
    - ./Project


### Refrence
- Basic code from Assignment 3 of my CG assignment    